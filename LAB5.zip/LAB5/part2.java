package proj11;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class part2 {
    public static void main(String[] args) {
        // Set ChromeDriver path
        System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver");

        // Launch browser
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        // Explicit wait
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        try {
            // -----------------------------
            // Step 1: Launch the URL
            // -----------------------------
            driver.get("https://tutorialsninja.com/demo/");

            // Step 2: Verify Title
            String expectedTitle = "Your Store";
            String actualTitle = driver.getTitle();
            if (expectedTitle.equals(actualTitle)) {
                System.out.println("✅ Title Verified: " + actualTitle);
            } else {
                System.out.println("❌ Title mismatch! Found: " + actualTitle);
            }

            // Step 3: Click 'My Account' dropdown
            WebElement myAccount = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='My Account']")));
            myAccount.click();

            // Step 4: Click 'Register'
            WebElement register = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Register")));
            register.click();

            // Step 5: Verify heading
            WebElement heading = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[text()='Register Account']")));
            if (heading.isDisplayed()) {
                System.out.println("✅ Heading Verified: " + heading.getText());
            }

            // -----------------------------
            // PERSONAL DETAILS VALIDATION
            // -----------------------------

            // First Name invalid (>32 chars)
            String longFirstName = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"; // 33 chars
            System.out.println("Attempting invalid First Name: " + longFirstName);
            WebElement firstName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("input-firstname")));
            firstName.clear();
            firstName.sendKeys(longFirstName);

            driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
            WebElement fnameError = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//div[contains(text(),'First Name must be between 1 and 32 characters!')]")
            ));
            System.out.println("First Name validation error: " + fnameError.getText());

            // Enter valid first name
            String validFirstName = "Shiva";
            firstName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("input-firstname")));
            firstName.clear();
            firstName.sendKeys(validFirstName);
            System.out.println("✅ Valid First Name entered: " + validFirstName);

            // Last Name invalid (>32 chars)
            String longLastName = "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB"; // 33 chars
            System.out.println("Attempting invalid Last Name: " + longLastName);
            WebElement lastName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("input-lastname")));
            lastName.clear();
            lastName.sendKeys(longLastName);

            driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
            WebElement lnameError = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//div[contains(text(),'Last Name must be between 1 and 32 characters!')]")
            ));
            System.out.println("Last Name validation error: " + lnameError.getText());

            // Enter valid last name
            String validLastName = "Teja";
            lastName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("input-lastname")));
            lastName.clear();
            lastName.sendKeys(validLastName);
            System.out.println("✅ Valid Last Name entered: " + validLastName);

            // Enter valid email
            String testEmail = "test1" + System.currentTimeMillis() + "@gmail.com";
            WebElement email = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("input-email")));
            email.sendKeys(testEmail);
            System.out.println("✅ Email entered: " + testEmail);

            // Enter valid telephone
            String testPhone = "9876543210";
            WebElement phone = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("input-telephone")));
            phone.sendKeys(testPhone);
            System.out.println("✅ Telephone entered: " + testPhone);

            // -----------------------------
            // PASSWORD VALIDATION
            // -----------------------------

            // Short password (<4 chars)
            String shortPassword = "123";
            System.out.println("Attempting invalid Password: " + shortPassword);
            WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("input-password")));
            password.clear();
            password.sendKeys(shortPassword);

            driver.findElement(By.cssSelector("input[type='submit'][value='Continue']")).click();
            WebElement passError = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//div[contains(text(),'Password must be between 4 and 20 characters!')]")
            ));
            System.out.println("Password validation error: " + passError.getText());

            // Enter valid password
            String validPass = "Abcd1234";
            password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("input-password")));
            password.clear();
            password.sendKeys(validPass);

            WebElement confirmPass = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("input-confirm")));
            confirmPass.clear();
            confirmPass.sendKeys(validPass);
            System.out.println("✅ Valid Password entered: " + validPass);

            // -----------------------------
            // NEWSLETTER & PRIVACY POLICY
            // -----------------------------

            WebElement newsletterYes = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='newsletter' and @value='1']")));
            newsletterYes.click();
            System.out.println("✅ Newsletter 'Yes' selected");

            WebElement privacyCheckbox = wait.until(ExpectedConditions.elementToBeClickable(By.name("agree")));
            privacyCheckbox.click();
            System.out.println("✅ Privacy Policy checkbox checked");

            driver.findElement(By.cssSelector("input.btn.btn-primary[value='Continue']")).click();
            System.out.println("✅ Continue clicked after Privacy Policy");

            // Verify account creation success
            WebElement successMsg = new WebDriverWait(driver, Duration.ofSeconds(30))
                    .until(ExpectedConditions.visibilityOfElementLocated(
                            By.xpath("//h1[contains(text(),'Your Account Has Been Created')]")
                    ));
            if (successMsg.isDisplayed()) {
                System.out.println("✅ Account creation confirmed: " + successMsg.getText());
            }

            // Click 'Continue' after account creation
            driver.findElement(By.cssSelector("a.btn.btn-primary")).click();

            // Navigate to Order History
            WebElement myAccountMenu = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='My Account']")));
            myAccountMenu.click();
            WebElement orderHistoryLink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Order History")));
            orderHistoryLink.click();

            WebElement orderHistoryHeading = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[text()='Order History']")));
            if (orderHistoryHeading.isDisplayed()) {
                System.out.println("✅ Navigated to Order History page");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}
