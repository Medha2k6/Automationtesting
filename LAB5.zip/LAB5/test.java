package proj11;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;   // ✅ missing
import org.openqa.selenium.By; 


public class test {
	public static void main(String[] args) throws InterruptedException {
    WebDriverManager.chromedriver().setup();
    WebDriver driver = new ChromeDriver();

    driver.get("https://google.com/");
    WebElement search = driver.findElement(By.name("q"));
    search.sendKeys("Automation testing tools");
    search.submit();

    Thread.sleep(5000);  // waits 5 seconds

    driver.quit();
	}

}
