package proj11;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RegisterTest {
    public static void main(String[] args) throws InterruptedException {
        // Launch browser
        WebDriver driver = new ChromeDriver();

        // Step 1: Launch the URL
        driver.get("https://tutorialsninja.com/demo/");
        driver.manage().window().maximize();
        Thread.sleep(2000);

        // Step 2: Verify Title of the page
        String expectedTitle = "Your Store";
        String actualTitle = driver.getTitle();
        if (expectedTitle.equals(actualTitle)) {
            System.out.println("✅ Title Verified: " + actualTitle);
        } else {
            System.out.println("❌ Title mismatch! Found: " + actualTitle);
        }

        // Step 3: Click on 'My Account' dropdown
        WebElement myAccount = driver.findElement(By.xpath("//span[text()='My Account']"));
        myAccount.click();
        Thread.sleep(1000);

        // Step 4: Select 'Register' from dropdown
        WebElement register = driver.findElement(By.linkText("Register"));
        register.click();
        Thread.sleep(2000);

        // Step 5: Verify heading ‘Register Account’
        WebElement heading = driver.findElement(By.xpath("//h1[text()='Register Account']"));
        if (heading.isDisplayed()) {
            System.out.println("✅ Heading Verified: " + heading.getText());
        } else {
            System.out.println("❌ Heading not found!");
        }

        // Step 6: Click on 'Continue' button at the bottom
        WebElement continueBtn = driver.findElement(By.xpath("//input[@value='Continue']"));
        continueBtn.click();
        Thread.sleep(2000);

        // Step 7: Verify warning message
        WebElement warning = driver.findElement(By.xpath("//div[contains(@class,'alert-danger')]"));
        if (warning.getText().contains("Warning: You must agree to the Privacy Policy!")) {
            System.out.println("✅ Warning Verified: " + warning.getText());
        } else {
            System.out.println("❌ Warning message mismatch!");
        }

        // Close browser
        driver.quit();
    }
}
